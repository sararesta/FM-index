library(testthat)
test_check("FMIndex")
