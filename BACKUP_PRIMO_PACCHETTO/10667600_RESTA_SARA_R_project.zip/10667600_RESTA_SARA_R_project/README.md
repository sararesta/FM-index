# R PROJECT: PROJECT 6, FM index
The package FMIndex requires an R version >=4.1.0